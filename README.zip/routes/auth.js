import express from 'express';
import {
  signup,
  login,
  verify,
  requestReset,
  validatePin,
  updatePassword,
  generatePin
} from '../controllers/authController.js';

const router = express.Router();

router.post('/signup', signup);
router.post('/login', login);
router.post('/verify', verify);
router.post('/request-reset', requestReset);
router.post('/validate-pin', validatePin);
router.post('/update-password', updatePassword);
router.post('/generate-pin', generatePin);

export default router;
