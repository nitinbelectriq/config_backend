import express from 'express';
import bodyParser from 'body-parser';
import dotenv from 'dotenv';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import authRoutes from './routes/auth.js';
import filesRoutes from './routes/files.js';

dotenv.config();
const app = express();

// Security middlewares
app.use(helmet());
app.use(cors());
app.use(bodyParser.json({limit: '10kb'}));

// Basic rate limiter
const limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 60 // limit each IP to 60 requests per windowMs
});
app.use(limiter);

// If behind a proxy (nginx, cloud), trust proxy so we can check X-Forwarded-Proto
app.set('trust proxy', 1);

// Redirect HTTP -> HTTPS when not in development
app.use((req, res, next) => {
  try {
    if (process.env.NODE_ENV === 'production') {
      const proto = req.get('x-forwarded-proto');
      if (proto && proto !== 'https') {
        return res.redirect(301, 'https://' + req.get('host') + req.originalUrl);
      }
    }
  } catch (e) { /* don't leak errors */ }
  next();
});

app.use('/auth', authRoutes);
app.use('/files', filesRoutes);

app.get('/', (req, res) => res.json({ok:true,message: ' Node backend running'}));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log('Server listening on port', port));
